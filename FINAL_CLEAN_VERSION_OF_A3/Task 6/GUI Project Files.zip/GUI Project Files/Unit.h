//---------------------------------------------------------------------------

#ifndef UnitH
#define UnitH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Forms.hpp>
#include <FMX.Controls.Presentation.hpp>
#include <FMX.StdCtrls.hpp>
#include <FMX.Types.hpp>
//---------------------------------------------------------------------------
class TConnect4Form : public TForm
{
__published:	// IDE-managed Components
	TButton *Button50;
	TButton *Button51;
	TButton *Button53;
	TButton *Button54;
	TButton *Button56;
	TButton *Button52;
	TButton *Button55;
	TButton *Button40;
	TButton *Button41;
	TButton *Button43;
	TButton *Button44;
	TButton *Button46;
	TButton *Button42;
	TButton *Button45;
	TButton *Button30;
	TButton *Button31;
	TButton *Button33;
	TButton *Button34;
	TButton *Button36;
	TButton *Button32;
	TButton *Button35;
	TButton *Button11;
	TButton *Button21;
	TButton *Button24;
	TButton *Button26;
	TButton *Button22;
	TButton *Button25;
	TButton *Button10;
	TButton *Button20;
	TButton *Button13;
	TButton *Button14;
	TButton *Button16;
	TButton *Button12;
	TButton *Button15;
	TButton *Button00;
	TButton *Button01;
	TButton *Button03;
	TButton *Button04;
	TButton *Button06;
	TButton *Button02;
	TButton *Button05;
	TLabel *CurrentPlayerSymbolLabel;
	TLabel *ErrorLabel;
	TButton *Button0;
	TButton *Button1;
	TButton *Button2;
	TButton *Button3;
	TButton *Button4;
	TButton *Button5;
	TButton *Button6;
	TLabel *Label1;
	TButton *Button23;
	TButton *ResetButton;
	void __fastcall ButtonClick(TObject *Sender);
	void __fastcall ButtonClick1(TObject *Sender);
	void __fastcall ResetButtonClick(TObject *Sender);
private:	// User declarations
	bool TConnect4Form::is_winner();
	bool TConnect4Form::is_draw();
public:		// User declarations
	__fastcall TConnect4Form(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TConnect4Form *Connect4Form;
//---------------------------------------------------------------------------
#endif
