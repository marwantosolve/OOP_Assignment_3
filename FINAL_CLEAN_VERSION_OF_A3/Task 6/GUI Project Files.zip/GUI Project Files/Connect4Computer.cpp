//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "Connect4Computer.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TConnect4ComputerForm *Connect4ComputerForm;
char board[6][7];
bool gameover;
int moves;
bool TConnect4ComputerForm::is_winner(){
	for (int i = 0; i < 6; i++){
        for (int j = 0; j< 7; j++){
            if(board [i][j] == 0){
                continue;
            }
            if (j < 4){
                if(board [i][j] == board [i][j + 1] && board [i][j] == board [i][j + 2] && board [i][j] == board [i][j + 3]){
                    return true;
                }
            }
            if (i < 3){
                if(board [i][j] == board [i + 1][j] && board [i][j] == board [i + 2][j] && board [i][j] == board [i + 3][j]){
                    return true;
                }
            }
            if (i < 3 && j < 4){
                if(board [i][j] == board [i + 1][j + 1] && board [i][j] == board [i + 2][j + 2] && board [i][j] == board [i + 3][j + 3]){
                    return true;
                }
            }
            if (i < 3 && j > 2){
                if(board [i][j] == board [i + 1][j - 1] && board [i][j] == board [i + 2][j - 2] && board [i][j] == board [i + 3][j - 3]){
                    return true;
                }
            }
        }
	}
    return false;
}
bool TConnect4ComputerForm::is_draw(){
	if(moves == 6*7)
		return true;
    else
        return false;
}
void TConnect4ComputerForm::UpdateBoard(){
    Button00->Text = board[0][0];
	Button01->Text = board[0][1];
	Button02->Text = board[0][2];
	Button03->Text = board[0][3];
	Button04->Text = board[0][4];
	Button05->Text = board[0][5];
	Button06->Text = board[0][6];

	Button10->Text = board[1][0];
	Button11->Text = board[1][1];
	Button12->Text = board[1][2];
	Button13->Text = board[1][3];
	Button14->Text = board[1][4];
	Button15->Text = board[1][5];
	Button16->Text = board[1][6];

	Button20->Text = board[2][0];
	Button21->Text = board[2][1];
	Button22->Text = board[2][2];
	Button23->Text = board[2][3];
	Button24->Text = board[2][4];
	Button25->Text = board[2][5];
	Button26->Text = board[2][6];

	Button30->Text = board[3][0];
	Button31->Text = board[3][1];
	Button32->Text = board[3][2];
	Button33->Text = board[3][3];
	Button34->Text = board[3][4];
	Button35->Text = board[3][5];
	Button36->Text = board[3][6];

	Button40->Text = board[4][0];
	Button41->Text = board[4][1];
	Button42->Text = board[4][2];
	Button43->Text = board[4][3];
	Button44->Text = board[4][4];
	Button45->Text = board[4][5];
	Button46->Text = board[4][6];

	Button50->Text = board[5][0];
	Button51->Text = board[5][1];
	Button52->Text = board[5][2];
	Button53->Text = board[5][3];
	Button54->Text = board[5][4];
	Button55->Text = board[5][5];
	Button56->Text = board[5][6];
}
//---------------------------------------------------------------------------
__fastcall TConnect4ComputerForm::TConnect4ComputerForm(TComponent* Owner)
	: TForm(Owner)
{
    ErrorLabel->Text = "";
	memset(board, 0, sizeof(board));
    UpdateBoard();
	moves = 0;
	gameover = false;
}
//---------------------------------------------------------------------------
void __fastcall TConnect4ComputerForm::ButtonClick(TObject *Sender)
{
	if(!gameover){
	ErrorLabel->Text = "";
	TButton* ClickedButton = dynamic_cast<TButton*>(Sender);
	 int r = 5;
	 int y = ClickedButton->Name[7]-'0';
		while(board[r][y] != 0){
			r--;
		}
		if(r < 0){
			ErrorLabel->Text = "\t\tPlease choose a valid move";
            return ;
		}
		else{
			board[r][y] = 'X';
			moves++;
			UpdateBoard();
			if(is_winner()){
				gameover = true;
				ErrorLabel->Text = "\t\tYou Won !!";
			}
			if(is_draw()){
				gameover = true;
				ErrorLabel->Text = "\t\tIt's a draw !";
			}
		}
	}
	if(!gameover){
		while(true){
			int r = 5;
			int y = ((int) (rand() % 7));
            while(board[r][y] != 0){
			r--;
			}
			if(r < 0){
                continue;
			}
			else{
				board[r][y] = 'O';
				moves++;
				UpdateBoard();
				if(is_winner()){
                    gameover = true;
                    ErrorLabel->Text = "Computer Won !";
				}
                if(is_draw()){
					gameover = true;
					ErrorLabel->Text = "It's a draw !";

				}
                break;
            }
		}
	}
}
//---------------------------------------------------------------------------
void __fastcall TConnect4ComputerForm::Button1Click(TObject *Sender)
{
    if(!gameover){
	ErrorLabel->Text = "";
	ErrorLabel->Text = " Please Press The Arrow Button Above The Desired Column";
	}
}
//---------------------------------------------------------------------------

void __fastcall TConnect4ComputerForm::ResetButtonClick(TObject *Sender)
{
	memset(board, 0, sizeof(board));
    UpdateBoard();
	gameover = false;
	moves = 0;
	ErrorLabel->Text = "";
}
//---------------------------------------------------------------------------
