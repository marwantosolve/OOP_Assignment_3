//---------------------------------------------------------------------------
#include <fmx.h>
#pragma hdrstop
#include "Unit.h"
#include "Interface.h"
#include "Connect4Computer.h"
#include "Connect4Menu.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Connect4ButtonClick(TObject *Sender)
{
	Connect4MenuForm->Show();
}
//---------------------------------------------------------------------------
