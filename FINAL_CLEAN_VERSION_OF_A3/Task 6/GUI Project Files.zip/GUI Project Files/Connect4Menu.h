//---------------------------------------------------------------------------

#ifndef Connect4MenuH
#define Connect4MenuH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Forms.hpp>
#include <FMX.Controls.Presentation.hpp>
#include <FMX.StdCtrls.hpp>
#include <FMX.Types.hpp>
//---------------------------------------------------------------------------
class TConnect4MenuForm : public TForm
{
__published:	// IDE-managed Components
	TButton *Button1;
	TButton *Button2;
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TConnect4MenuForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TConnect4MenuForm *Connect4MenuForm;
//---------------------------------------------------------------------------
#endif
