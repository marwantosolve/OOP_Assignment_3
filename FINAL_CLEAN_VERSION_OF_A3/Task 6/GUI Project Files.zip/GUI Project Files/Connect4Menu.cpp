//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop
#include "Connect4Menu.h"
#include "Connect4Computer.h"
#include "Unit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TConnect4MenuForm *Connect4MenuForm;
//---------------------------------------------------------------------------
__fastcall TConnect4MenuForm::TConnect4MenuForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TConnect4MenuForm::Button1Click(TObject *Sender)
{
    Connect4Form->Show();
}
//---------------------------------------------------------------------------
void __fastcall TConnect4MenuForm::Button2Click(TObject *Sender)
{
    Connect4ComputerForm->Show();
}
//---------------------------------------------------------------------------
