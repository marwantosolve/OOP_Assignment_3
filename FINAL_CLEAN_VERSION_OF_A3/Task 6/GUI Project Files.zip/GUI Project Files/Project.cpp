//---------------------------------------------------------------------------

#include <fmx.h>
#ifdef _WIN32
#include <tchar.h>
#endif
#pragma hdrstop
#include <System.StartUpCopy.hpp>
//---------------------------------------------------------------------------
//USEFORM("Pyramic.cpp", PyramicForm);
USEFORM("Unit.cpp", Connect4Form);
USEFORM("Connect4Menu.cpp", Connect4MenuForm);
USEFORM("Connect4Computer.cpp", Connect4ComputerForm);
USEFORM("Interface.cpp", Form1);
//---------------------------------------------------------------------------
extern "C" int FMXmain()
{
	try
	{
		Application->Initialize();
		Application->CreateForm(__classid(TForm1), &Form1);
		Application->CreateForm(__classid(TConnect4Form), &Connect4Form);
		Application->CreateForm(__classid(TConnect4MenuForm), &Connect4MenuForm);
		Application->CreateForm(__classid(TConnect4ComputerForm), &Connect4ComputerForm);
		Application->Run();
	}
	catch (Exception &exception)
	{
		Application->ShowException(&exception);
	}
	catch (...)
	{
		try
		{
			throw Exception("");
		}
		catch (Exception &exception)
		{
			Application->ShowException(&exception);
		}
	}
	return 0;
}
//---------------------------------------------------------------------------
